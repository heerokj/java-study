package day07hw;

import java.awt.Frame;

public class Q13 {
	public static void main(String[] args) {
		Frame f = new Frame();
		f.setSize(300, 300);
		f.setLocation(400, 400);
		f.setVisible(true);
		f.setTitle("Hello Window World");
	}

}
